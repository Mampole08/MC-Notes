package com.example.mampole;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {
private Button startGame;
private CheckBox checkbox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }start game = (Button)findViewById(R.Id.button);
    startGame.setOnClickListener(new View.OnClickListener()
    public void onClick(View v))

    }
}
}
